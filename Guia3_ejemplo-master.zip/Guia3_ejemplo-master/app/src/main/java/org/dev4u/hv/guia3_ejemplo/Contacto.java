package org.dev4u.hv.guia3_ejemplo;

/**
 * Created by admin on 30/8/17.
 */

public class Contacto {
    public String nombre;
    public String numero;

    public Contacto(String nombre, String numero) {
        this.nombre = nombre;
        this.numero = numero;
    }
}
